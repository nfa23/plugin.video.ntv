# _*_ coding:utf-8 _*_
import sys,os
import xbmc,xbmcplugin,xbmcgui
from urlparse import parse_qsl,parse_qs
import urllib2,urllib
import xbmcaddon

# Get the plugin url in plugin:// notation.
base_url = sys.argv[0]
# Get the plugin handle as an integer number.
addon_handle = int(sys.argv[1])
args = parse_qs(sys.argv[2][1:])
addon = xbmcaddon.Addon()
tvcat_url = 'http://218.93.10.156:9000/f/5cf4a59eb5/?raw=1'
tvlist_url = 'http://218.93.10.156:9000/f/594827b9a7/?raw=1'

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

def showDialog(line1,line2,line3):
    __addon__ = xbmcaddon.Addon()
    __addonname__ = __addon__.getAddonInfo('name')
    xbmcgui.Dialog().ok(__addonname__, line1, line2, line3)

def downloadFile(tvlist,savePath):
    try:
        tvlist = tvlist.strip()
        savePath = savePath.strip()
        r = urllib2.Request(tvlist)
        req = urllib2.urlopen(r)
        saveFile = open(savePath, 'wb')
        saveFile.write(req.read())
        saveFile.close()
        req.close()
    except:
        print 'Download file error,please check the settings.'
        
def get_tvlist():
    cdir = os.path.split(os.path.realpath(__file__))[0]
    lfile = os.path.join(cdir,'tvurl.txt')
    tlist = []    
    f = open(lfile,'r')    
    a = f.readline()
    while a:
        b = a.replace('\n','').split(',')
        tlist.append(b)
        a = f.readline()
    f.close()
    return tlist

def get_tvcat():
    cdir = os.path.split(os.path.realpath(__file__))[0]
    lfile = os.path.join(cdir, 'tvcat.txt')
    clist = []
    f = open(lfile,'r')
    a = f.readline()
    while a:
        b = a.replace('\n','').split(',')
        clist.append(b)
        a = f.readline()
    f.close()
    return clist

def playCustom():
    kb = xbmc.Keyboard('', '', False)
    kb.doModal()
    if (kb.isConfirmed() and len(kb.getText()) > 0):
        xPlaylist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        vdurl = kb.getText().strip()
        xPlaylist.clear()
        listitem =xbmcgui.ListItem ('Custom Url')
        listitem.setInfo('Custom video', {'Title': 'Custom Url', 'Genre': 'Custom'})
        xPlaylist.add(url=vdurl,listitem=listitem)
        xbmc.Player().play(xPlaylist)
        
def refresh_channel():
    print '-------------downloading--------------'
    cdir = os.path.split(os.path.realpath(__file__))[0]
    cfile = os.path.join(cdir,'tvcat.txt')
    lfile = os.path.join(cdir,'tvurl.txt')
    downloadFile(tvcat_url, cfile)
    downloadFile(tvlist_url,lfile)
    list_cat()

def list_channel(cat_id):
    tlist = get_tvlist()
    for chan in tlist:
        if int(chan[0]) == cat_id or cat_id == 0:
            li = xbmcgui.ListItem(chan[1])
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=addon_handle,url=chan[2],listitem=li)
    xbmcplugin.endOfDirectory(addon_handle)

def list_cat():
    clist = get_tvcat()
    alltxt = '全部'
    li = xbmcgui.ListItem(alltxt)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'catgory', 'cat': 0}), listitem=li, isFolder=True)
    for ca in clist:
        li = xbmcgui.ListItem(ca[1])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'catgory', 'cat': ca[0]}), listitem=li, isFolder=True)
    customtxt = '自定义地址播放'
    li = xbmcgui.ListItem(customtxt)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'custom'}), listitem=li)
    refreshtxt = '更新播放列表'
    li = xbmcgui.ListItem(refreshtxt)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'refresh'}), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def router(paramstr):
    params = dict(parse_qsl(paramstr))
    if params:
        if params['mode'] == 'custom':
            playCustom()
        elif params['mode'] == 'refresh':
            refresh_channel()
        elif params['mode'] == 'catgory':
            list_channel(int(params['cat']))
    else:
        list_cat()

if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
